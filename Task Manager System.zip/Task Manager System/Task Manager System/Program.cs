using Microsoft.EntityFrameworkCore;
using Task_Manager_System.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
// Add services to the container
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configure Authentication with Cookies
builder.Services.AddAuthentication("MyCookieAuth") // Ensure this matches the scheme in SignInAsync
    .AddCookie("MyCookieAuth", options =>
    {
        options.LoginPath = "/Account/Login";// Set the login page path
        options.LogoutPath = "/Account/Logout";
        options.LogoutPath = "/Account/signin";// Set the logout page path
        options.AccessDeniedPath = "/Account/AccessDenied"; // Set access denied page path, if needed
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}


app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication(); // Enable authentication
app.UseAuthorization();  // Enable authorization


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Dashboard}/{id?}");
app.MapControllerRoute(
    name: "Users",
    pattern: "{controller=Users}/{action=UsersPage}/{id?}");
app.MapControllerRoute(
    name: "Tasks",
    pattern: "{controller=Tasks}/{action=TasksPage}/{id?}");
app.MapControllerRoute(
    name: "Report",
    pattern: "{controller=Report}/{action=ReportPage}/{id?}");

app.Run();
