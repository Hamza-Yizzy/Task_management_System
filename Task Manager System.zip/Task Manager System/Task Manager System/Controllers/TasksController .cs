﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Security.Claims;
using Task_Manager_System.Data;
using Task_Manager_System.Models;

namespace Task_Manager_System.Controllers
{

    public class TasksController : Controller
    {
        private readonly ApplicationDbContext _context;
        public TasksController(ApplicationDbContext context)
        {
            _context = context;
        }
    
        public IActionResult TaskDetail(int id)
        {
            // Retrieve the task by id
            var task = _context.Tasks.FirstOrDefault(t => t.TaskId == id);

            // Check if the task exists
            if (task == null)
            {
                return NotFound();
            }

            // Retrieve assigned users
            var assignedByUser = _context.Users.FirstOrDefault(u => u.user_id == task.AssignedBy);
            var assignedToUser = _context.Users.FirstOrDefault(u => u.user_id == task.AssignedTo);

            // Create the view model
            var taskViewModel = new TaskItem
            {
                TaskId = task.TaskId,
                Title = task.Title,
                Status = task.Status,
                Duration= task.Duration,
                AssignedTime = task.AssignedTime,
                DueDate = task.DueDate,
               
            };

            return View(taskViewModel);
        }

        [HttpGet]
        public IActionResult TasksPage()
        {
            var tasks = from task in _context.Tasks
                        join userBy in _context.Users on task.AssignedBy equals userBy.user_id
                        join userTo in _context.Users on task.AssignedTo equals userTo.user_id
                        select new TaskViewModel
                        {
                            TaskId = task.TaskId,
                            Title = task.Title,
                            Status = task.Status,
                            AssignedTime = task.AssignedTime,
                            DueDate = task.DueDate,
                            AssignedByUsername = userBy.Username,
                            AssignedToUsername = userTo.Username
                        };

            return View(tasks.ToList());
        }


        // GET: Tasks/Create
        [HttpGet]
        public IActionResult TaskReg()
        {
            var employees = _context.Users
        .Where(u => u.Role == Role.Employee)
        .Select(u => new { u.user_id, u.Username })
        .ToList();

            // Check how many employees were found
            if (!employees.Any())
            {
                // Log or handle the case where no employees are found
                Console.WriteLine("No employees found.");
            }

            ViewBag.Employees = new SelectList(employees, "user_id", "Username");
            // Optionally, populate roles if they are dynamic.

            return View();
        }

        // POST: Tasks/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult TaskReg(TaskItem task)
        {
            if (ModelState.IsValid)
            {
                task.AssignedTime = DateTime.Now; // Set current time
                task.UpdatedAt = DateTime.Now; // Set current time for updates
                // Get the logged-in user's ID
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Or the appropriate claim type for your user ID

                // Set the user ID for Assigned_By (or any other relevant property)
                task.AssignedBy = int.Parse(userId); // Assuming Assigned_By is of type INT
                                                     // Set default status to "Pending" if not already set
                task.Status = task.Status ?? "Pending";
                _context.Tasks.Add(task);
                _context.SaveChanges();
                return RedirectToAction("TasksPage");
            }
            var employees = _context.Users
        .Where(u => u.Role == Role.Employee)
        .Select(u => new { u.user_id, u.Username })
        .ToList();

            ViewBag.Employees = new SelectList(employees, "user_id", "Username");


            return View(task);
        }

        // GET: Tasks/Edit/5
        public IActionResult Edit(int id)
        {
            var task = _context.Tasks.Find(id);
            if (task == null)
            {
                return NotFound();
            }

            // Retrieve employees for the dropdown list
            var employees = _context.Users
                .Where(u => u.Role == Role.Employee)
                .Select(u => new { u.user_id, u.Username })
                .ToList();

            ViewBag.Employees = new SelectList(employees, "user_id", "Username");
            ViewBag.Status = new List<string> { "Complete", "Pending", "Incomplete" };

            // Pass the current user role to the view
            ViewBag.UserRole = User.FindFirst(ClaimTypes.Role)?.Value;

            return View(task);
        }

        // POST: Tasks/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, TaskItem task)
        {
            // Check if the user exists
            var existingTask = _context.Tasks.Find(id);
            if (existingTask == null)
            {
                return NotFound();
            }

            // Update the existing user's properties
            existingTask.Title = task.Title;
            existingTask.Description = task.Description;
            existingTask.Status = task.Status;
            existingTask.DueDate = task.DueDate;
            existingTask.Duration = task.Duration;
            existingTask.UpdatedAt = DateTime.Now;
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Or the appropriate claim type for your user ID

            // Set the user ID for Assigned_By (or any other relevant property)
            existingTask.AssignedBy = int.Parse(userId); // Assuming Assigned_By is of type INT

            // Ensure foreign key assignments are handled properly
            
            existingTask.AssignedTo = task.AssignedTo; // Assignee's user ID

           

            if (ModelState.IsValid)
            {
                _context.SaveChanges();
                return RedirectToAction("TasksPage");
            }

            return View(task); // Return the view with the model if there are validation errors
        }


        // GET: Tasks/Delete/5
        public IActionResult Delete(int id)
        {
            var task = _context.Tasks.Find(id);
            if (task == null)
            {
                return NotFound();
            }
            return View(task);
        }

        // POST: Tasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var task = _context.Tasks.Find(id);
            if (task != null)
            {
                _context.Tasks.Remove(task);
                _context.SaveChanges();
                return RedirectToAction("tasksPage");
            }
            return RedirectToAction("TasksPage");
        }

        [HttpPost, ActionName("ChangeStatus")]
        [ValidateAntiForgeryToken]
        public IActionResult StatusConfirmed(int id)
        {
            var task = _context.Tasks.Find(id);
            if (task != null)
            {
                // Check if the task status is "Pending"
                if (task.Status == "Pending")
                {
                    // Update the task's status to "Completed"
                    task.Status = "Complete";
                    _context.SaveChanges();
                }
                // Redirect to the task detail page with the updated information
                return RedirectToAction("TaskDetail", new { id = task.TaskId });
            }
            return NotFound();
        }



    }
}
