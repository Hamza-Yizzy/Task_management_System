﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task_Manager_System.Data;
using Task_Manager_System.Models;
using Task_Manager_System.Models;
using System.Security.Claims;
namespace Task_Manager_System.Controllers
{
    public class ReportController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReportController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult ReportPage()
        {
            // Load all tasks initially
            var tasks = _context.Tasks.ToList();

            // Create the ViewModel with initial values for StatusOptions, UsernameOptions, and RoleOptions
            var viewModel = new ReportViewModel
            {
                Tasks = tasks,
                StatusOptions = new List<string> { "Complete", "Pending", "Incomplete" },
                UsernameOptions = _context.Users.Select(u => u.Username).Distinct().ToList(),
                RoleOptions = _context.Users.Select(u => u.Role.ToString()).Distinct().ToList()
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult ReportPage(string selectedStatus, string selectedUsername, string selectedRole)
        {
            // Start with all tasks
            var tasksQuery = _context.Tasks.AsQueryable();

            // Apply filters if they are set
            if (!string.IsNullOrEmpty(selectedStatus))
            {
                tasksQuery = tasksQuery.Where(t => t.Status == selectedStatus);
            }

            if (!string.IsNullOrEmpty(selectedUsername))
            {
                var user = _context.Users.FirstOrDefault(u => u.Username == selectedUsername);
                if (user != null)
                {
                    tasksQuery = tasksQuery.Where(t => t.AssignedTo == user.user_id);
                }
            }

            if (!string.IsNullOrEmpty(selectedRole))
            {
                var usersWithRole = _context.Users
                    .AsEnumerable() // Switching to client-side evaluation for Role filtering
                    .Where(u => u.Role.ToString() == selectedRole)
                    .Select(u => u.user_id)
                    .ToList();

                tasksQuery = tasksQuery.Where(t => usersWithRole.Contains(t.AssignedTo));
            }

            // Create the ViewModel with filtered tasks and the options for the dropdowns
            var viewModel = new ReportViewModel
            {
                Tasks = tasksQuery.ToList(),
                SelectedStatus = selectedStatus,
                SelectedUsername = selectedUsername,
                SelectedRole = selectedRole,
                StatusOptions = new List<string> { "Complete", "Pending", "Incomplete" },
                UsernameOptions = _context.Users.Select(u => u.Username).Distinct().ToList(),
                RoleOptions = _context.Users.Select(u => u.Role.ToString()).Distinct().ToList()
            };

            return View(viewModel);
        }

        }
}
