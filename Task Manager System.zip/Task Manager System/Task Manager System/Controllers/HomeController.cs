using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using Task_Manager_System.Data;
using Task_Manager_System.Models;

namespace Task_Manager_System.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Dashboard()
        {
            // Get the user's role
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            var userId = User.Identity.Name; // Assumes this is unique (e.g., User ID or Username)
            var user = _context.Users.AsEnumerable().FirstOrDefault(u => u.Role.ToString() == userRole);
            IQueryable<Task_Manager_System.Models.TaskItem> tasksQuery;

            // Filter tasks based on the user's role
            if (userRole == "Administrator")
            {
                // Admin sees all tasks
                tasksQuery = _context.Tasks;
            }
            else if (userRole == "Manager")
            {
                // Manager sees tasks they assigned
                tasksQuery = _context.Tasks.Where(t => t.AssignedBy == user.user_id);
            }
            else
            {
                // Employee sees only tasks assigned to them
                tasksQuery = _context.Tasks.Where(t => t.AssignedTo == user.user_id);
            }

            var tasks = tasksQuery.ToList();
            // Calculate task statistics based on filtered tasks
            int totalTasks = tasks.Count;
            int completedTasks = tasks.Count(t => t.Status.ToString() == "Complete");
            int inProgressTasks = tasks.Count(t => t.Status.ToString() == "Incomplete");
            int waitingTasks = tasks.Count(t => t.Status.ToString() == "Pending");

            // Calculate completion percentage
            int progressPercentage = totalTasks > 0 ? (completedTasks * 100) / totalTasks : 0;

            // Pass data to the view
            ViewData["TotalTasks"] = totalTasks;
            ViewData["CompletedTasks"] = completedTasks;
            ViewData["InProgressTasks"] = inProgressTasks;
            ViewData["WaitingTasks"] = waitingTasks;
            ViewData["ProgressPercentage"] = progressPercentage;
            // Pass the tasks to the view
            ViewData["Tasks"] = tasks;

            return View();
        }

        //public IActionResult Dashboard()
        //{
        //    // Get the user's role
        //    var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
        //    var userId = User.Identity.Name; // Assumes this is unique (e.g., User ID or Username)

        //    // Use AsEnumerable to move the filtering to client-side
        //    var user = _context.Users.AsEnumerable().FirstOrDefault(u => u.Role.ToString() == userRole);

        //    IQueryable<Task_Manager_System.Models.TaskItem> tasksQuery;

        //    // Filter tasks based on the user's role
        //    if (userRole == "Administrator")
        //    {
        //        // Admin sees all tasks
        //        tasksQuery = _context.Tasks;
        //    }
        //    else if (userRole == "Manager")
        //    {
        //        // Manager sees tasks they assigned
        //        tasksQuery = _context.Tasks.Where(t => t.AssignedBy == user.user_id);
        //    }
        //    else
        //    {
        //        // Employee sees only tasks assigned to them
        //        tasksQuery = _context.Tasks.Where(t => t.AssignedTo == user.user_id);
        //    }

        //    var tasks = tasksQuery.ToList();

        //    // Calculate task statistics based on filtered tasks
        //    int totalTasks = tasks.Count;
        //    int completedTasks = tasks.Count(t => t.Status.ToString() == "Complete");
        //    int inProgressTasks = tasks.Count(t => t.Status.ToString() == "Incomplete");
        //    int waitingTasks = tasks.Count(t => t.Status.ToString() == "Pending");

        //    // Calculate completion percentage
        //    int progressPercentage = totalTasks > 0 ? (completedTasks * 100) / totalTasks : 0;

        //    // Pass data to the view
        //    ViewData["TotalTasks"] = totalTasks;
        //    ViewData["CompletedTasks"] = completedTasks;
        //    ViewData["InProgressTasks"] = inProgressTasks;
        //    ViewData["WaitingTasks"] = waitingTasks;
        //    ViewData["ProgressPercentage"] = progressPercentage;

        //    var taskes = tasksQuery.Select(t => new
        //    {
        //        t.Title,
        //        t.Status,
        //        t.AssignedTo,
        //        t.AssignedBy,
        //        Duration = t.Duration,
        //    }).ToList();

        //    ViewData["Tasks"] = taskes;

        //    return View();
        //}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
