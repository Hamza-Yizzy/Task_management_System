﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task_Manager_System.Data;
using Task_Manager_System.Models;
using Task_Manager_System.Models;
using System.Security.Claims;
namespace Task_Manager_System.Controllers
{
    public class ReportController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReportController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult ReportPage()
        {
            var tasks = (from task in _context.Tasks
                         join userBy in _context.Users on task.AssignedBy equals userBy.user_id
                         join userTo in _context.Users on task.AssignedTo equals userTo.user_id
                         select new TaskDTO
                         {
                             TaskId = task.TaskId,
                             Title = task.Title,
                             Status = task.Status,
                             AssignedByUsername = userBy.Username,
                             AssignedToUsername = userTo.Username,
                             UserRoleName = userTo.Role.ToString()
                         }).ToList();

            var viewModel = new ReportViewModel
            {
                Tasks = tasks,
                StatusOptions = new List<string> { "Complete", "Pending", "Incomplete" },
                UsernameOptions = _context.Users.Select(u => u.Username).Distinct().ToList(),
                RoleOptions = _context.Users.Select(u => u.Role.ToString()).Distinct().ToList()
            };

            return View(viewModel);
        }

[HttpPost]
        public IActionResult ReportPage(string selectedStatus, string selectedUsername, string selectedRole)
        {
            var tasksQuery = _context.Tasks.AsQueryable();

            if (!string.IsNullOrEmpty(selectedStatus))
            {
                tasksQuery = tasksQuery.Where(t => t.Status == selectedStatus);
            }

            if (!string.IsNullOrEmpty(selectedUsername))
            {
                var user = _context.Users.FirstOrDefault(u => u.Username == selectedUsername);
                if (user != null)
                {
                    tasksQuery = tasksQuery.Where(t => t.AssignedTo == user.user_id);
                }
            }

            if (!string.IsNullOrEmpty(selectedRole))
            {
                // Assuming Role is an enum, convert the selectedRole string back to the enum type
                if (Enum.TryParse(typeof(Role), selectedRole, out var roleValue))
                {
                    var usersWithRole = _context.Users
                        .Where(u => u.Role == (Role)roleValue)
                        .Select(u => u.user_id)
                        .ToList();

                    tasksQuery = tasksQuery.Where(t => usersWithRole.Contains(t.AssignedTo));
                }
            }

            var tasks = (from task in tasksQuery
                         join userBy in _context.Users on task.AssignedBy equals userBy.user_id
                         join userTo in _context.Users on task.AssignedTo equals userTo.user_id
                         select new TaskDTO
                         {
                             TaskId = task.TaskId,
                             Title = task.Title,
                             Status = task.Status,
                             AssignedByUsername = userBy.Username,
                             AssignedToUsername = userTo.Username,
                             UserRoleName = userTo.Role.ToString() // Still convert to string for display purposes
                         }).ToList();

            var viewModel = new ReportViewModel
            {
                Tasks = tasks,
                SelectedStatus = selectedStatus,
                SelectedUsername = selectedUsername,
                SelectedRole = selectedRole,
                StatusOptions = new List<string> { "Complete", "Pending", "Incomplete" },
                UsernameOptions = _context.Users.Select(u => u.Username).Distinct().ToList(),
                RoleOptions = Enum.GetNames(typeof(Role)).ToList() // Assuming Role is an enum
            };

            return View(viewModel);
        }

    }
}
