﻿using Microsoft.AspNetCore.Mvc;
using Task_Manager_System.Data;
using Task_Manager_System.Models;

namespace Task_Manager_System.Controllers
{

    public class UsersController : Controller
    {
        private readonly ApplicationDbContext _context;
        public UsersController(ApplicationDbContext context)
        {
            _context = context;
        }
        // GET: Users
        public IActionResult UsersPage()
        {
            var users = _context.Users.ToList();
            return View(users);
        }
        // GET: Users/Create
        public IActionResult UserReg()
        {
            // Optionally, populate roles if they are dynamic.
            ViewBag.Role = new List<string> { "Administrator", "Manager", "Employee" };
            return View();
        }

        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UserReg(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(user); // Do not set user.user_id
                _context.SaveChanges();
                return RedirectToAction("UsersPage");
            }
            return View(user);
        }

        // GET: Users/Edit/5
        public IActionResult Edit(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }
            ViewBag.Role = new List<string> { "Administrator", "Manager", "Employee" };
            return View(user);
        }

        // POST: Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, User user)
        {
            // Check if the user exists
            var existingUser = _context.Users.Find(id);
            if (existingUser == null)
            {
                return NotFound();
            }

            // Update the existing user's properties
            existingUser.Username = user.Username;
            existingUser.Password = user.Password; // Consider hashing the password before saving
            existingUser.Role = user.Role;
            existingUser.Email = user.Email;

            if (ModelState.IsValid)
            {
                _context.SaveChanges();
                return RedirectToAction("UsersPage");
            }

            return View(user); // Return the view with the model if there are validation errors
        }


        // GET: Users/Delete/5
        public IActionResult Delete(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
                return RedirectToAction("UsersPage");
            }
            return RedirectToAction("UsersPage");
        }

    }
}
