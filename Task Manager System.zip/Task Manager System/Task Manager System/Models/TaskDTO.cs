﻿namespace Task_Manager_System.Models
{
    public class TaskDTO
    {
        public int TaskId { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string AssignedByUsername { get; set; }
        public string AssignedToUsername { get; set; }
        public string UserRoleName { get; set; }
    }
}
