﻿
namespace Task_Manager_System.Models
{
    public class ReportViewModel
    {
        public List<TaskItem> Tasks { get; set; }  // List of filtered tasks

        // Filter criteria
        public string SelectedStatus { get; set; }
        public string SelectedUsername { get; set; }
        public string SelectedRole { get; set; }

        // Dropdown data
        public List<string> StatusOptions { get; set; }
        public List<string> UsernameOptions { get; set; }
        public List<string> RoleOptions { get; set; }

    }
}
