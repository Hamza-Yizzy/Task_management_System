﻿namespace Task_Manager_System.Models
{
    public class TaskViewModel
    {
        public int TaskId { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public DateTime AssignedTime { get; set; }
        public DateTime DueDate { get; set; }
        public string AssignedByUsername { get; set; }
        public string AssignedToUsername { get; set; }
    }
}
