﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Task_Manager_System.Models
{
    public class TaskItem
    {
        [Key]
        [Column("task_id")]
        public int TaskId { get; set; }

        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("status")]
        public string Status { get; set; } = "Pending";  // Default value

        [Column("assigned_time")]
        public DateTime AssignedTime { get; set; }

        [Column("due_date")]
        public DateTime DueDate { get; set; }

        [Column("duration")]
        public int? Duration { get; set; }

      
        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; }
        // Foreign Keys
        
        [Column("assigned_by")]
        public int AssignedBy { get; set; }
        
        
        [Column("assigned_to")]
        public int AssignedTo { get; set; }
       
    }

    // Enum for Task Status
    public enum TaskStatus
    {
        Complete,
        Pending,
        Incomplete
    }
}
