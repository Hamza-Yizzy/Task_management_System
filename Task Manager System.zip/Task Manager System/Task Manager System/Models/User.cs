﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Task_Manager_System.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int user_id { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; }

        [Required]
        [StringLength(255)]
        public string Password { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public Role Role { get; set; } // Enum property to be stored as string

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime created_at { get; set; } = DateTime.Now;
    }

    public enum Role
    {
        Administrator,
        Manager,
        Employee
    }


}
