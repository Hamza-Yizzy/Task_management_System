﻿using Microsoft.EntityFrameworkCore;
using Task_Manager_System.Models;

namespace Task_Manager_System.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<TaskItem> Tasks { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .Property(u => u.Role)
                .HasConversion(
                    r => r.ToString(),
                    r => (Role)Enum.Parse(typeof(Role), r)); // Convert enum to string and back

            base.OnModelCreating(modelBuilder);
        }




    }
}
